# gateway-kong

![Version: 1.0.0](https://img.shields.io/badge/Version-1.0.0-informational?style=flat-square) ![Type: application](https://img.shields.io/badge/Type-application-informational?style=flat-square) ![AppVersion: dev](https://img.shields.io/badge/AppVersion-dev-informational?style=flat-square)

A Helm chart for EnkryptAI Kong Gateway

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| affinity | object | `{}` |  |
| autoscaling.enabled | bool | `true` |  |
| autoscaling.maxReplicas | int | `2` |  |
| autoscaling.minReplicas | int | `1` |  |
| autoscaling.targetCPUUtilizationPercentage | int | `80` |  |
| configMaps.fluentBit.enabled | bool | `true` |  |
| configMaps.fluentBit.name | string | `"fluent-bit-config"` |  |
| configMaps.kongConfig.enabled | bool | `true` |  |
| configMaps.kongConfig.name | string | `"gateway-kong-temp-config"` |  |
| deck.leaderboard.enabled | bool | `false` | Adds the `enkrypt_leaderboard` decK service and the public leaderboard consumer. Needs `DECK_LEADERBOARD_AUTH`, `DECK_LEADERBOARD_DETAILS_PASSWORD`, `DECK_LEADERBOARD_PUBLIC_CONSUMER_EMAIL` and `DECK_LEADERBOARD_PUBLIC_CONSUMER_API_KEY` in `gateway-env-secret`. Set `true` when `leaderboard-server` runs. |
| deck.mcpScanner.enabled | bool | `false` | Adds the `enkrypt_mcp_scanner` decK service. Needs `DECK_MCP_SCANNER_BASIC_AUTH`. Set `true` when `mcp-scanner` runs. |
| deck.skillScanner.enabled | bool | `false` | Adds the `enkrypt_skill_scanner` decK service. Needs `DECK_MCP_SCANNER_BASIC_AUTH`. Set `true` when `skill-scanner` runs. |
| externalSecrets.enabled | bool | `true` |  |
| externalSecrets.repoName | string | `"enkryptai/gateway"` |  |
| externalSecrets.secretStoreRefName | string | `"enkryptai-clustersecret-store"` |  |
| fullnameOverride | string | `"gateway-kong"` |  |
| image.fluentBit.pullPolicy | string | `"IfNotPresent"` |  |
| image.fluentBit.repository | string | `"fluent/fluent-bit"` |  |
| image.fluentBit.tag | string | `"3.2.1"` |  |
| image.gateway.pullPolicy | string | `"IfNotPresent"` |  |
| image.gateway.repository | string | `"188451452903.dkr.ecr.us-east-1.amazonaws.com/enkryptai-dev/gateway"` |  |
| image.gateway.tag | string | `"dev"` |  |
| image.sync.pullPolicy | string | `"IfNotPresent"` |  |
| image.sync.repository | string | `"188451452903.dkr.ecr.us-east-1.amazonaws.com/enkryptai-dev/gateway-sync"` |  |
| image.sync.tag | string | `"dev"` |  |
| ingress.annotations."cert-manager.io/cluster-issuer" | string | `"letsencrypt-prod"` |  |
| ingress.annotations."nginx.ingress.kubernetes.io/proxy-buffer-size" | string | `"128k"` |  |
| ingress.className | string | `""` | Empty: `global.ingress.className` (enkryptai-stack), else the cluster default IngressClass |
| ingress.enabled | bool | `true` |  |
| ingress.hosts[0].host | string | `"api.dev.enkryptai.com"` |  |
| ingress.hosts[0].paths[0].path | string | `"/"` |  |
| ingress.hosts[0].paths[0].pathType | string | `"Prefix"` |  |
| ingress.tls[0].hosts[0] | string | `"api.dev.enkryptai.com"` |  |
| ingress.tls[0].secretName | string | `"gateway-kong-tls"` |  |
| livenessProbe.enabled | bool | `true` |  |
| livenessProbe.exec.command[0] | string | `"kong"` |  |
| livenessProbe.exec.command[1] | string | `"health"` |  |
| livenessProbe.failureThreshold | int | `10` |  |
| livenessProbe.initialDelaySeconds | int | `10` |  |
| livenessProbe.periodSeconds | int | `10` |  |
| livenessProbe.successThreshold | int | `1` |  |
| livenessProbe.timeoutSeconds | int | `10` |  |
| nameOverride | string | `""` |  |
| nodeSelector | object | `{}` |  |
| replicaCount | int | `2` |  |
| resources.fluentBit.limits.cpu | string | `"0.5"` |  |
| resources.fluentBit.limits.memory | string | `"256Gi"` |  |
| resources.fluentBit.requests.cpu | string | `"0.1"` |  |
| resources.fluentBit.requests.memory | string | `"64Mi"` |  |
| resources.gateway.limits.cpu | string | `"2"` |  |
| resources.gateway.limits.memory | string | `"4Gi"` |  |
| resources.gateway.requests.cpu | string | `"0.5"` |  |
| resources.gateway.requests.memory | string | `"1.5Gi"` |  |
| resources.sync.limits.cpu | string | `"0.5"` |  |
| resources.sync.limits.memory | string | `"256Mi"` |  |
| resources.sync.requests.cpu | string | `"0.1"` |  |
| resources.sync.requests.memory | string | `"64Mi"` |  |
| service.ports.admin.port | int | `8001` |  |
| service.ports.admin.targetPort | int | `8001` |  |
| service.ports.adminGui.port | int | `8002` |  |
| service.ports.adminGui.targetPort | int | `8002` |  |
| service.ports.fluentBitAdmin.port | int | `5043` |  |
| service.ports.fluentBitAdmin.targetPort | int | `5043` |  |
| service.ports.fluentBitMetrics.port | int | `2020` |  |
| service.ports.fluentBitMetrics.targetPort | int | `2020` |  |
| service.ports.http.port | int | `80` |  |
| service.ports.http.targetPort | int | `8000` |  |
| service.ports.https.port | int | `443` |  |
| service.ports.https.targetPort | int | `8443` |  |
| service.type | string | `"ClusterIP"` |  |
| tolerations | list | `[]` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
