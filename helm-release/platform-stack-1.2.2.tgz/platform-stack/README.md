# platform-stack

![Version: 1.1.3](https://img.shields.io/badge/Version-1.1.3-informational?style=flat-square) ![AppVersion: 1.1.3](https://img.shields.io/badge/AppVersion-1.1.3-informational?style=flat-square)

Complete platform infrastructure stack

## Requirements

| Repository | Name | Version |
|------------|------|---------|
| https://enkryptai.github.io/helm-charts | platform-core(platform-core) | 1.1.0 |

## Values

| Key | Type | Default | Description |
|-----|------|---------|-------------|
| adminpassword.secretName | string | `"opensearch-cred"` |  |
| aws.region | string | `"us-west-2"` |  |
| clustername | string | `"enkryptai-opensearch"` |  |
| databasekong.repository | string | `"onprem/postgres"` |  |
| databasekong.tag | int | `16` |  |
| externalSecret.enabled | bool | `false` |  |
| global.platform | string | `"azure"` |  |
| global.registry | string | `"vpcdeployment.azurecr.io"` |  |
| migrationjob.repository | string | `"onprem/postgres"` |  |
| migrationjob.tag | int | `15` |  |
| openfga.backup | object | `{}` | Rendered into the CNPG Cluster spec.backup (fresh install only) |
| openfga.plugins | list | `[]` | Rendered into the CNPG Cluster spec.plugins, e.g. Barman Cloud (fresh install only) |
| openfga.repository | string | `"onprem/postgresql"` |  |
| openfga.tag | string | `"17.4-8"` |  |
| opensearch.dashboards.image | string | `"vpcdeployment.azurecr.io/onprem/opensearch-dashboards:3.2.0"` |  |
| opensearch.general.image | string | `"vpcdeployment.azurecr.io/onprem/opensearch:3.2.0"` |  |
| opensearch.initHelper.image | string | `"vpcdeployment.azurecr.io/onprem/busybox:latest"` |  |
| opensearch.security | string | `nil` |  |
| opensearch.securityconfig | bool | `false` |  |
| opensearch.users.admin.hash | string | `""` |  |
| opensearch.users.dashboarduser.hash | string | `""` |  |
| opensearch.users.kibana_read_only.hash | string | `""` |  |
| opensearch.users.kong_logs_plugin.hash | string | `""` |  |
| platform-core.argo-events.configs.jetstream.settings.maxFileStore | int | `-1` |  |
| platform-core.argo-events.configs.jetstream.settings.maxMemoryStore | int | `-1` |  |
| platform-core.argo-events.configs.jetstream.streamConfig.discard | int | `0` |  |
| platform-core.argo-events.configs.jetstream.streamConfig.duplicates | string | `"300s"` |  |
| platform-core.argo-events.configs.jetstream.streamConfig.maxAge | string | `"72h"` |  |
| platform-core.argo-events.configs.jetstream.streamConfig.maxBytes | string | `"1GB"` |  |
| platform-core.argo-events.configs.jetstream.streamConfig.maxMsgs | int | `1000000` |  |
| platform-core.argo-events.configs.jetstream.streamConfig.replicas | int | `3` |  |
| platform-core.argo-events.configs.jetstream.streamConfig.retention | int | `0` |  |
| platform-core.argo-events.configs.jetstream.versions[0].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.14.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[0].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.14.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[0].natsImage | string | `"nats:2.10.10"` |  |
| platform-core.argo-events.configs.jetstream.versions[0].startCommand | string | `"/nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[0].version | string | `"latest"` |  |
| platform-core.argo-events.configs.jetstream.versions[1].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.7.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[1].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[1].natsImage | string | `"nats:2.8.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[1].startCommand | string | `"/nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[1].version | string | `"2.8.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[2].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.7.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[2].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[2].natsImage | string | `"nats:2.8.1-alpine"` |  |
| platform-core.argo-events.configs.jetstream.versions[2].startCommand | string | `"nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[2].version | string | `"2.8.1-alpine"` |  |
| platform-core.argo-events.configs.jetstream.versions[3].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.7.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[3].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[3].natsImage | string | `"nats:2.8.2"` |  |
| platform-core.argo-events.configs.jetstream.versions[3].startCommand | string | `"/nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[3].version | string | `"2.8.2"` |  |
| platform-core.argo-events.configs.jetstream.versions[4].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.7.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[4].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[4].natsImage | string | `"nats:2.8.2-alpine"` |  |
| platform-core.argo-events.configs.jetstream.versions[4].startCommand | string | `"nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[4].version | string | `"2.8.2-alpine"` |  |
| platform-core.argo-events.configs.jetstream.versions[5].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.7.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[5].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[5].natsImage | string | `"nats:2.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[5].startCommand | string | `"/nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[5].version | string | `"2.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[6].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.7.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[6].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[6].natsImage | string | `"nats:2.9.12"` |  |
| platform-core.argo-events.configs.jetstream.versions[6].startCommand | string | `"/nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[6].version | string | `"2.9.12"` |  |
| platform-core.argo-events.configs.jetstream.versions[7].configReloaderImage | string | `"natsio/nats-server-config-reloader:0.7.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[7].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.9.1"` |  |
| platform-core.argo-events.configs.jetstream.versions[7].natsImage | string | `"nats:2.9.16"` |  |
| platform-core.argo-events.configs.jetstream.versions[7].startCommand | string | `"/nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[7].version | string | `"2.9.16"` |  |
| platform-core.argo-events.configs.jetstream.versions[8].configReloaderImage | string | `"vpcdeployment.azurecr.io/onprem/nats-server-config-reloader:0.14.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[8].metricsExporterImage | string | `"vpcdeployment.azurecr.io/onprem/prometheus-nats-exporter:0.14.0"` |  |
| platform-core.argo-events.configs.jetstream.versions[8].natsImage | string | `"vpcdeployment.azurecr.io/onprem/nats:2.10.10"` |  |
| platform-core.argo-events.configs.jetstream.versions[8].startCommand | string | `"/nats-server"` |  |
| platform-core.argo-events.configs.jetstream.versions[8].version | string | `"2.10.10"` |  |
| platform-core.argo-events.configs.nats.versions[0].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:latest"` |  |
| platform-core.argo-events.configs.nats.versions[0].natsStreamingImage | string | `"nats-streaming:latest"` |  |
| platform-core.argo-events.configs.nats.versions[0].version | string | `"latest"` |  |
| platform-core.argo-events.configs.nats.versions[1].metricsExporterImage | string | `"natsio/prometheus-nats-exporter:0.8.0"` |  |
| platform-core.argo-events.configs.nats.versions[1].natsStreamingImage | string | `"nats-streaming:0.22.1"` |  |
| platform-core.argo-events.configs.nats.versions[1].version | string | `"0.22.1"` |  |
| platform-core.argo-events.global.image.imagePullPolicy | string | `"IfNotPresent"` |  |
| platform-core.argo-events.global.image.repository | string | `"vpcdeployment.azurecr.io/onprem/argo-events"` |  |
| platform-core.argo-events.global.image.tag | string | `"v1.9.7"` |  |
| platform-core.argo-events.namespaceOverride | string | `"enkryptai-stack"` |  |
| platform-core.argo-workflows.controller.image.registry | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.argo-workflows.controller.image.repository | string | `"onprem/workflow-controller"` |  |
| platform-core.argo-workflows.controller.image.tag | string | `"v3.7.1"` |  |
| platform-core.argo-workflows.controller.namespaceParallelism | string | `"10"` |  |
| platform-core.argo-workflows.controller.retentionPolicy.completed | int | `10` |  |
| platform-core.argo-workflows.controller.retentionPolicy.errored | int | `3` |  |
| platform-core.argo-workflows.controller.retentionPolicy.failed | int | `3` |  |
| platform-core.argo-workflows.executor.args | list | `[]` |  |
| platform-core.argo-workflows.executor.env | list | `[]` |  |
| platform-core.argo-workflows.executor.image.pullPolicy | string | `""` |  |
| platform-core.argo-workflows.executor.image.registry | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.argo-workflows.executor.image.repository | string | `"onprem/argoexec"` |  |
| platform-core.argo-workflows.executor.image.tag | string | `"v3.6.14"` |  |
| platform-core.argo-workflows.executor.resources | object | `{}` |  |
| platform-core.argo-workflows.executor.securityContext | object | `{}` |  |
| platform-core.argo-workflows.images.pullPolicy | string | `"Always"` |  |
| platform-core.argo-workflows.images.pullSecrets | list | `[]` |  |
| platform-core.argo-workflows.images.tag | string | `""` |  |
| platform-core.argo-workflows.server.baseHref | string | `"/"` |  |
| platform-core.argo-workflows.server.deploymentAnnotations | object | `{}` |  |
| platform-core.argo-workflows.server.enabled | bool | `true` |  |
| platform-core.argo-workflows.server.image.registry | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.argo-workflows.server.image.repository | string | `"onprem/argocli"` |  |
| platform-core.argo-workflows.server.image.tag | string | `"v3.7.1"` |  |
| platform-core.argo-workflows.server.podAnnotations | object | `{}` |  |
| platform-core.argo-workflows.server.podLabels | object | `{}` |  |
| platform-core.argo-workflows.server.podSecurityContext | object | `{}` |  |
| platform-core.argo-workflows.server.rbac.create | bool | `true` |  |
| platform-core.argo-workflows.server.securityContext.allowPrivilegeEscalation | bool | `false` |  |
| platform-core.argo-workflows.server.securityContext.capabilities.drop[0] | string | `"ALL"` |  |
| platform-core.argo-workflows.server.securityContext.readOnlyRootFilesystem | bool | `false` |  |
| platform-core.argo-workflows.server.securityContext.runAsNonRoot | bool | `true` |  |
| platform-core.argo-workflows.singleNamespace | bool | `false` |  |
| platform-core.cloudnative-pg.enabled | bool | `true` |  |
| platform-core.cloudnative-pg.image.repository | string | `"vpcdeployment.azurecr.io/onprem/cloudnative-pg"` |  |
| platform-core.cloudnative-pg.image.tag | string | `"1.27.0"` |  |
| platform-core.gpu-operator.ccManager.image | string | `"onprem/k8s-cc-manager"` |  |
| platform-core.gpu-operator.ccManager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.ccManager.version | string | `"v0.1.1"` |  |
| platform-core.gpu-operator.dcgm.image | string | `"onprem/dcgm-exporter"` |  |
| platform-core.gpu-operator.dcgm.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.dcgm.version | string | `"3.3.8-3.6.0-ubuntu22.04"` |  |
| platform-core.gpu-operator.dcgmExporter.image | string | `"onprem/dcgm-exporter"` |  |
| platform-core.gpu-operator.dcgmExporter.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.dcgmExporter.version | string | `"3.3.8-3.6.0-ubuntu22.04"` |  |
| platform-core.gpu-operator.devicePlugin.image | string | `"onprem/k8s-device-plugin"` |  |
| platform-core.gpu-operator.devicePlugin.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.devicePlugin.version | string | `"v0.17.0-ubi9"` |  |
| platform-core.gpu-operator.driver.image | string | `"onprem/nvidia-driver"` |  |
| platform-core.gpu-operator.driver.manager.image | string | `"onprem/k8s-driver-manager"` |  |
| platform-core.gpu-operator.driver.manager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.driver.manager.version | string | `"v0.10.0"` |  |
| platform-core.gpu-operator.driver.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.driver.version | string | `"580.126.20"` |  |
| platform-core.gpu-operator.gdrcopy.image | string | `"onprem/gdrdrv"` |  |
| platform-core.gpu-operator.gdrcopy.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.gdrcopy.version | string | `"v2.4.1-2"` |  |
| platform-core.gpu-operator.gfd.image | string | `"onprem/k8s-device-plugin"` |  |
| platform-core.gpu-operator.gfd.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.gfd.version | string | `"v0.17.0-ubi9"` |  |
| platform-core.gpu-operator.kataManager.image | string | `"onprem/k8s-kata-manager"` |  |
| platform-core.gpu-operator.kataManager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.kataManager.version | string | `"v0.2.2"` |  |
| platform-core.gpu-operator.migManager.image | string | `"onprem/k8s-mig-manager"` |  |
| platform-core.gpu-operator.migManager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.migManager.version | string | `"v0.10.0-ubuntu20.04"` |  |
| platform-core.gpu-operator.node-feature-discovery.image.repository | string | `"vpcdeployment.azurecr.io/onprem/node-feature-discovery"` |  |
| platform-core.gpu-operator.node-feature-discovery.image.tag | string | `"v0.16.6"` |  |
| platform-core.gpu-operator.nodeStatusExporter.image | string | `"onprem/gpu-operator-validator"` |  |
| platform-core.gpu-operator.nodeStatusExporter.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.nodeStatusExporter.version | string | `"v26.3.0"` |  |
| platform-core.gpu-operator.operator.image | string | `"onprem/gpu-operator"` |  |
| platform-core.gpu-operator.operator.initContainer.image | string | `"onprem/gpu-operator-init"` |  |
| platform-core.gpu-operator.operator.initContainer.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.operator.initContainer.version | string | `"v26.3.0"` |  |
| platform-core.gpu-operator.operator.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.operator.version | string | `"v26.3.0"` |  |
| platform-core.gpu-operator.sandboxDevicePlugin.image | string | `"onprem/kubevirt-gpu-device-plugin"` |  |
| platform-core.gpu-operator.sandboxDevicePlugin.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.sandboxDevicePlugin.version | string | `"v1.2.10"` |  |
| platform-core.gpu-operator.toolkit.image | string | `"onprem/container-toolkit"` |  |
| platform-core.gpu-operator.toolkit.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.toolkit.version | string | `"v1.13.1-ubi8"` |  |
| platform-core.gpu-operator.validator.image | string | `"onprem/gpu-operator-validator"` |  |
| platform-core.gpu-operator.validator.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.validator.version | string | `"v26.3.0"` |  |
| platform-core.gpu-operator.vfioManager.image | string | `"onprem/cuda"` |  |
| platform-core.gpu-operator.vfioManager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.vfioManager.version | string | `"12.6.2-base-ubi9"` |  |
| platform-core.gpu-operator.vgpuDeviceManager.image | string | `"onprem/vgpu-device-manager"` |  |
| platform-core.gpu-operator.vgpuDeviceManager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.vgpuDeviceManager.version | string | `"v0.2.8"` |  |
| platform-core.gpu-operator.vgpuManager.driverManager.image | string | `"onprem/k8s-driver-manager"` |  |
| platform-core.gpu-operator.vgpuManager.driverManager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.gpu-operator.vgpuManager.driverManager.version | string | `"v0.10.0"` |  |
| platform-core.gpu-operator.vgpuManager.image | string | `"onprem/vgpu-manager"` |  |
| platform-core.gpu-operator.vgpuManager.repository | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.keydb.imageRepository | string | `"vpcdeployment.azurecr.io/onprem/keydb"` |  |
| platform-core.keydb.imageTag | string | `"x86_64_v6.3.2"` |  |
| platform-core.nack.jetstream.enabled | bool | `true` |  |
| platform-core.nack.jetstream.image.registry | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.nack.jetstream.image.repository | string | `"onprem/jetstream-controller"` |  |
| platform-core.nack.jetstream.image.tag | string | `"0.19.1"` |  |
| platform-core.nack.nats.url | string | `"nats://nats:4222"` |  |
| platform-core.namespaces[0].labels.name | string | `"argo-events"` |  |
| platform-core.namespaces[0].name | string | `"argo-events"` |  |
| platform-core.nats.container.image.repository | string | `"onprem/nats"` |  |
| platform-core.nats.container.image.tag | string | `"2.11.8-alpine"` |  |
| platform-core.nats.global.image.registry | string | `"vpcdeployment.azurecr.io"` |  |
| platform-core.nats.natsBox.container.image.repository | string | `"onprem/nats-box"` |  |
| platform-core.nats.natsBox.container.image.tag | string | `"0.18.0"` |  |
| platform-core.nats.promExporter.image.repository | string | `"onprem/prometheus-nats-exporter"` |  |
| platform-core.nats.promExporter.image.tag | string | `"0.17.3"` |  |
| platform-core.nats.reloader.image.repository | string | `"onprem/nats-server-config-reloader"` |  |
| platform-core.nats.reloader.image.tag | string | `"0.19.1"` |  |
| platform-core.opensearch-operator.kubeRbacProxy.image.repository | string | `"vpcdeployment.azurecr.io/onprem/kube-rbac-proxy"` |  |
| platform-core.opensearch-operator.kubeRbacProxy.image.tag | string | `"v0.15.0"` |  |
| platform-core.opensearch-operator.manager.image.repository | string | `"vpcdeployment.azurecr.io/onprem/opensearch-operator"` |  |
| platform-core.opensearch-operator.manager.image.tag | string | `"2.8.0"` |  |
| sensor.jobImage | string | `"vpcdeployment.azurecr.io/enkryptai-dev/redteam-job"` |  |
| sensor.jobversion | string | `"prod-v1.0.98"` |  |
| sensor.natsURL | string | `"nats://nats.enkryptai-stack:4222"` |  |
| supabase.backup | object | `{}` | Rendered into the CNPG Cluster spec.backup (fresh install only) |
| supabase.plugins | list | `[]` | Rendered into the CNPG Cluster spec.plugins, e.g. Barman Cloud (fresh install only) |
| supabase.repository | string | `"supabase"` |  |
| supabase.tag | string | `"16.0.3"` |  |

----------------------------------------------
Autogenerated from chart metadata using [helm-docs v1.14.2](https://github.com/norwoodj/helm-docs/releases/v1.14.2)
